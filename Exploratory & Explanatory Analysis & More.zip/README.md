# Ford-Go-Bike-Data-Explanatory-Analysis
- Most of the users are Males.
- There is no apparent relation what so ever between user's gender and the duration of the trip.
- There is no apparent relation between user's type (Either Customer or Subscriber) and the duration of the trip.
# Limitations:
- There is no enough parameters to know which actually affects the duration of the trip.
