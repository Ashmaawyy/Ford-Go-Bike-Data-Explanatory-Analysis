# Ford-Go-Bike-Data-Explanatory-Analysis
# Project Walkthrough
- First things first I first cleaned the data from null values and extra columns.
- Then I worked my way through the data in exploratory analysis.
- I investigated the duration variable against all the other variables available in the dataset.
- I executed Univariate, Bivariate and Multivariate Explanatory analysies to distnguish relations between all other variables and the investgation variable.
### I tried my best with this data and came forth with these conclusions:
- Most of the users are Males.
- There is no apparent relation what so ever between user's gender and the duration of the trip.
- There is no apparent relation between user's type (Either Customer or Subscriber) and the duration of the trip.
- The most durations recorded are nearly in the range of 100 ~ 2000 Seconds by the three genders :)
- There appears a teeny tiny (expected) relation  betweeen age and duration of the trip since the longer durations are from users of younger age (usually).
- Most of the users are born between 1980 and 1990, which means the majority are adults between 31 to 41 years old.
# Limitations:
- There is no enough parameters to know which actually affects the duration of the trip.


### And I really can't think of any more sensible relations between the variables of this dataset :)
